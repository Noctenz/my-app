import React from 'react';

const Gallery = () => {
};

export default Gallery;
