const Gallery = () => {
  return (
    <div className="page">
      <h2>Galeri Produk</h2>
      <p>Koleksi plugin, tools, dan resource Minecraft dari Sovereign Studio.</p>
    </div>
  );
};

export default Gallery;
